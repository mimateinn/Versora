# Credits

Words by the Harbor Lights team.
Translation help from the community.
