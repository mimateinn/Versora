Harbor Lights fan translation kit.
Translate the files, keep the folder shape, drop it back into the mods folder.
